package com.niit.shoppingcart.test;





import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Bean;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.services.CategoryServices;

public class CategoryTest 
{
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		CategoryDAO categoryDAO= (CategoryDAO) context.getBean("categoryDAO");
		Category category= (Category)context.getBean("category");
		category.setId("CAT007");
		category.setName("Headphones");
		category.setDescription("Sony");
		categoryDAO.saveOrUpdate(category);
		context.close();
	}
}
