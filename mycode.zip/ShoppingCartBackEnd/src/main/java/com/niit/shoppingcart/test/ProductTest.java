/*package com.niit.shoppingcart.test;





import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Bean;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.services.ProductServices;

public class ProductTest 
{
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		ProductDAO productDAO= (ProductDAO) context.getBean("productDAO");
		Product product= (Product)context.getBean("product");
		product.setId("001");
		product.setName("SAMSUNG GALAXY S7");
		product.setDescription("MOBILE");
		product.setPrice("48000");
		productDAO.saveOrUpdate(product);
		context.close();
	}
}
*/