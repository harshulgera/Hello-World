package com.niit.shoppingcart.dao;


	import java.util.List;

import javax.imageio.spi.IIOServiceProvider;

import org.hibernate.Criteria;
	import org.hibernate.Query;
	import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.User;



	@Repository("userDAO")
	public class UserDAOImpl implements UserDAO
	{

		private static final Logger log = LoggerFactory.getLogger(SupplierDAOImpl.class);
		
		@Autowired
		private SessionFactory sessionFactory;
		public UserDAOImpl()
		{}
		
		/*public UserDAOImpl(SessionFactory sessionfactory)
		{
			this.sessionFactory = sessionfactory;
		}*/
		
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public void saveOrUpdate(User user)
		{
			log.debug("Starting of User SaveOrUpdate");
			//User user1= new User();
			//		user1.setId(id);
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			log.debug("Ending of User SaveOrUpdate");
		}
		
		@Transactional
		public void delete(String id)
		{
			log.debug("Starting of User Delete");
		
			User UserToDelete=new User();
			UserToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(UserToDelete);
			log.debug("Ending of User Delete");
			//SessionFactory factory=new sessionFactory();
	/*		
		Configuration c=new Configuration().configure();
		SessionFactory sfactory=c.buildSessionFactory();
		Session session=sfactory.getCurrentSession();
		Query q=session.createQuery("");
		*/	
		}
		
		
		@Transactional
		public User get(String id)
		{
			log.debug("Starting of User Get");
			//System.out.println("GET METHOD EXECUTED");
			//String hql="from USER where id="+"'"+id+"'";
			String hql = "from User where id= '" + id + "'";
			//System.out.println("query executed");
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			List<User>listUser=(List<User>)query.list();
			if(listUser!=null&& !listUser.isEmpty())
			{
				return listUser.get(0);
				
			}
			log.debug("Ending of User Get");
			return null;
		}
		
		@Transactional
		public boolean isValidUser(String id, String password) 
		{
			log.debug("Starting of isValidUser");
			
			System.out.println("user checking");
			String hql = "from User where id= '" + id + "' and " + " password ='" + password+"'";
			
			System.out.println("FETCHING DATA");
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			System.out.println("data fetched");
			@SuppressWarnings("unchecked")
			List<User> list = (List<User>) query.list();
			log.debug("Ending of isValidUser");
			if (list != null && !list.isEmpty())
			{
				System.out.println("Returning True");
				return true;			
			}
			else
			{
				System.out.println("Returning False");
				return false;
			}
			/*boolean isValid=false;
				
				if(id.equals("sa") && password.equals("sa"))
				{
						isValid=true;
						System.out.println("datbase Connected");
				}*/
			
		}

		
		@Transactional
		public List<User>list()
		{
			log.debug("Starting of User List");
			
			@SuppressWarnings("unchecked")
			List<User>listDetails=(List<User>)
			sessionFactory.getCurrentSession().createCriteria(User.class)
			.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			log.debug("Ending of User List");
			return listDetails;
			
		}
	
	}



