package com.niit.shoppingcart.dao;


	import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
/*import org.hibernate.annotations.common.util.impl.Log_.log;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.niit.shoppingcart.model.Category;


	@Repository("categoryDAO")
	public class CategoryDAOImpl implements CategoryDAO
	{
		/*private static Logger log=Logger.getlogger(CategoryDAOImpl.class);*/
		
		private static final Logger log = LoggerFactory.getLogger(CategoryDAOImpl.class);
		
		@Autowired
		private SessionFactory sessionFactory;
		public CategoryDAOImpl()
		{}
		
		/*public CategoryDAOImpl(SessionFactory sessionfactory)
		{
			this.sessionFactory = sessionfactory;
		}*/
		
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public void saveOrUpdate(Category category)
		{
			log.debug("Saving Category");
			//Category category1= new Category();
			//		category1.setId(id);
			Session session=sessionFactory.getCurrentSession();
			
			if(session != null)
				
			{
			session.persist(category);
			System.out.println(category);
			}
			else
			{
				System.out.println("Session Not Created");
				log.debug("Session Not Created");
			}
			
			log.debug("Category Saved");
		
					}
		
		@Transactional
		public void delete(String id)
		{
			log.debug("Deleting Category");
			Category CategoryToDelete=new Category();
			CategoryToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(CategoryToDelete);
			log.debug("Category Deleted");
			
			//SessionFactory factory=new sessionFactory();
	/*		
		Configuration c=new Configuration().configure();
		SessionFactory sfactory=c.buildSessionFactory();
		Session session=sfactory.getCurrentSession();
		Query q=session.createQuery("");
		*/	
		}
		
		
		@Transactional
		public Category get(String id)
		{
			
			Category c=null;
//			String hql="from Category where id="+"'"+id+"'";
			//="select * from Category where id="+id;
			
			String hql="from User where id= '" + id + "'";
			
			log.debug("Fetching Category");
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		
		
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) query.list();
		
			if(listCategory!=null&& !listCategory.isEmpty())
			{
				
				System.out.println(listCategory.get(0));
				//return listCategory.get(0);
				log.debug("Category Not Fetched");
				c=listCategory.get(0);
			}
			log.debug("Category Fetched");
			
			return c;
			
		}
		
		@Transactional
		public List<Category> list()
		{
			log.debug("Calling Category List");
			
			@SuppressWarnings("unchecked")
			List<Category>listCategory=(List<Category>)sessionFactory.getCurrentSession().createCriteria(Category.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			
			/*for(Category c : listCategory)
			{
				System.out.println(c.getId() + c.getName());
			}*/
			
			log.debug("Returning Category List");
			return listCategory;
			
		}
		
	}



