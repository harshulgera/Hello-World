package com.niit.shoppingcart.dao;


	import java.util.List;

	import org.hibernate.Criteria;
	import org.hibernate.Query;
	import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Product;


	@Repository("productDAO")
	public class ProductDAOImpl implements ProductDAO
	{
		
		private static final Logger log = LoggerFactory.getLogger(ProductDAOImpl.class);
		
		@Autowired
		private SessionFactory sessionFactory;
		public ProductDAOImpl()
		{}
		
		/*public ProductDAOImpl(SessionFactory sessionfactory)
		{
			this.sessionFactory = sessionfactory;
		}*/
		
		public void setSessionFactory(SessionFactory sessionFactory) 
		{
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public void saveOrUpdate(Product product)
		{
			//Product product1= new Product();
			//		product1.setId(id);
			log.debug("Starting of Product SaveOrUpdate");
			sessionFactory.getCurrentSession().saveOrUpdate(product);
			log.debug("Ending of Product SaveOrUpdate");
		}
		
		@Transactional
		public void delete(String id)
		{
			log.debug("Starting of Product Delete");
			Product ProductToDelete=new Product();
			ProductToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(ProductToDelete);
			log.debug("Ending of Product Delete");
			
			//SessionFactory factory=new sessionFactory();
	/*		
		Configuration c=new Configuration().configure();
		SessionFactory sfactory=c.buildSessionFactory();
		Session session=sfactory.getCurrentSession();
		Query q=session.createQuery("");
		*/	
		}
		
		
		@Transactional
		public Product get(String id)
		{
			log.debug("Starting of Product Get");
			String hql="from User where id= '" + id + "'";
					//"from Product where id="+"'"+id+"'";
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			List<Product>listProduct=(List<Product>)query.list();
			if(listProduct!=null&& !listProduct.isEmpty())
			{
				return listProduct.get(0);
				
			}
			log.debug("Ending of Get Product");
			return null;
		}
		
		@Transactional
		public List<Product>list()
		{
			log.debug("Starting of Product LIST");
			
			@SuppressWarnings("unchecked")
			List<Product>listProduct=(List<Product>)sessionFactory.getCurrentSession().createCriteria(Product.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			log.debug("Ending of Product LIST");
			return listProduct;
		}
		
	}



