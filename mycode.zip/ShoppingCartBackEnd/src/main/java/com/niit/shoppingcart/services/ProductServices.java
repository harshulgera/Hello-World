package com.niit.shoppingcart.services;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.ProductDAOImpl;
import com.niit.shoppingcart.model.Product;

/*import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.ProductDAO;
*/
@Repository("productServices")
public class ProductServices 
{
	
	
	private ProductDAO dao;
	
	public ProductServices()
	{
		dao=new ProductDAOImpl();
	}



	public List<Product> listAllProduct()
	{
		return dao.list();
	}

	public Product getProductById(String Id)
	{
		return dao.get(Id);
	}
	
	public void deleteProductById(String id)
	{
		dao.delete(id);
	}
	
	public void saveOrUpdateProduct(String id)
	{
		dao.saveOrUpdate(null);
	}

}


	
