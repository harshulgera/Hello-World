package com.niit.shoppingcart.services;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.CategoryDAOImpl;
import com.niit.shoppingcart.model.Category;

/*import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.CategoryDAO;
*/
@Repository("categoryServices")
public class CategoryServices 
{
	
	
	private CategoryDAO dao;
	
	public CategoryServices()
	{
		dao=new CategoryDAOImpl();
	}



	public List<Category> listAllCategory()
	{
		return dao.list();
	}

	public Category getCategoryById(String Id)
	{
		return dao.get(Id);
	}
	
	public void deleteCategoryById(String id)
	{
		dao.delete(id);
	}
	
	public void saveOrUpdateCategory(Category c)
	{
		dao.saveOrUpdate(c);
	}

}


	
