package com.niit.shoppingcart.test;




import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Bean;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;


public class UserTest 
{
	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		UserDAO userDAO= (UserDAO) context.getBean("userDAO");
		User user=(User) context.getBean("user");
		
		
		if(userDAO.isValidUser("1803", "pass")==true)
		{
			System.out.println("UserVerified");
			User u=userDAO.get("0803");
			
			System.out.println(u.getMobile());
			System.out.println(user.getMobile());
			
		}
		else
		{
			System.out.println("anonymous user");
		}
		
		
	}
}
