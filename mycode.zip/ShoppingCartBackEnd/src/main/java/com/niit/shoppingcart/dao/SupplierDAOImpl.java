package com.niit.shoppingcart.dao;


	import java.util.List;

	import org.hibernate.Criteria;
	import org.hibernate.Query;
	import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.model.Supplier;


	@Repository("supplierDAO")
	public class SupplierDAOImpl implements SupplierDAO
	{
		private static final Logger log = LoggerFactory.getLogger(SupplierDAOImpl.class);
		
		@Autowired
		private SessionFactory sessionFactory;
		public SupplierDAOImpl()
		{}
		
		/*public SupplierDAOImpl(SessionFactory sessionfactory)
		{
			this.sessionFactory = sessionfactory;
		}*/
		
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public void saveOrUpdate(Supplier supplier)
		{
			log.debug("Starting of Product SaveOrUpdate");
		
			//Supplier supplier1= new Supplier();
			//		supplier1.setId(id);
			sessionFactory.getCurrentSession().saveOrUpdate(supplier);
			log.debug("Ending of Product SaveOrUpdate");
		}
		
		@Transactional
		public void delete(String id)
		{
			log.debug("Starting of Product Delete");
			Supplier SupplierToDelete=new Supplier();
			SupplierToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(SupplierToDelete);
			log.debug("Ending of Product Delete");
			//SessionFactory factory=new sessionFactory();
	/*		
		Configuration c=new Configuration().configure();
		SessionFactory sfactory=c.buildSessionFactory();
		Session session=sfactory.getCurrentSession();
		Query q=session.createQuery("");
		*/	
		}
		
		
		@Transactional
		public Supplier get(String id)
		{
			log.debug("Starting of Product GET");
			
			//"from Supplier where id="+"'"+id+"'";
			String hql="from User where id= '" + id + "'";
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			List<Supplier>listSupplier=(List/*<Supplier>*/)query.list();
			if(listSupplier!=null&& !listSupplier.isEmpty())
			{
				return listSupplier.get(0);
				
			}
			log.debug("Ending of Product GET");
			return null;
		}
		
		@Transactional
		public List<Supplier>list()
		{
			log.debug("Starting of Product LIST");
			
			@SuppressWarnings("unchecked")
			List<Supplier>listSupplier=(List<Supplier>)sessionFactory.getCurrentSession().createCriteria(Supplier.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			log.debug("Ending of Product LIST");
			return listSupplier;
		}
		
	}



