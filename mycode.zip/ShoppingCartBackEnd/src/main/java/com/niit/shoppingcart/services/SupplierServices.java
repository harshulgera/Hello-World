package com.niit.shoppingcart.services;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.SupplierDAOImpl;
import com.niit.shoppingcart.model.Supplier;

/*import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.SupplierDAO;
*/
@Repository("supplierServices")
public class SupplierServices 
{
	
	
	private SupplierDAO dao;
	
	public SupplierServices()
	{
		dao=new SupplierDAOImpl();
	}



	public List<Supplier> listAllSupplier()
	{
		return dao.list();
	}

	public Supplier getSupplierById(String Id)
	{
		return dao.get(Id);
	}
	
	public void deleteSupplierById(String id)
	{
		dao.delete(id);
	}
	
	public void saveOrUpdateSupplier(String id)
	{
		dao.saveOrUpdate(null);
	}

}


	
