package com.niit.shoppingcart.services;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.dao.UserDAOImpl;
import com.niit.shoppingcart.model.User;


/*import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.UserDAO;
*/
@Repository("userServices")
public class UserServices 
{
	
	
	private UserDAO dao;
	
	public UserServices()
	{
		dao=new UserDAOImpl();
	}



	public List<User> listAllUser()
	{
		return dao.list();
	}

	public User getUserById(String Id)
	{
		return dao.get(Id);
	}
	
	public void deleteUserById(String id)
	{
		dao.delete(id);
	}
	
	public void saveOrUpdateUser(String id)
	{
		dao.saveOrUpdate(null);
	}

}


	
