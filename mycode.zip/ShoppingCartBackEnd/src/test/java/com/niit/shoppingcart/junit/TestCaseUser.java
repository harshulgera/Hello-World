package com.niit.shoppingcart.junit;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class TestCaseUser 
{
	
	@Autowired
	static
	UserDAO userDAO;
	
	@Autowired
	static
	User user;
	
	@Autowired
	static
	AnnotationConfigApplicationContext context;
	
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		userDAO= (UserDAO) context.getBean("userDAO");
		user=(User) context.getBean("user");
		
	}


	@Test
	public void UserTestCase()
	{
		int size=userDAO.list().size();
		System.out.println(size);
		assertEquals("UserListTestCase",size,size);
		
		User u=userDAO.get("1803");
		String str=u.getId();
		assertEquals("User Test ID","1803",str);
		
		user.setId("1410");
		user.setPassword("wtf");
		user.setEmail("sinharitika45@gmail.com");
		user.setMobile("9783804978");
		user.setName("Ritika Sinha");
		user.setAddress("Bhopal");
		userDAO.saveOrUpdate(user);
		//Testing Saved User
		u=userDAO.get("1803");
		String st=u.getId();
		assertEquals("User Test ID","1803",st);
		
		user.setId("1410");
		user.setPassword("wtf");
		user.setEmail("nothing@nothing");
		user.setMobile("9783");
		user.setName("rohity");
		user.setAddress("pune");
		userDAO.saveOrUpdate(user);
		//Deleting Saved User
		userDAO.delete("1410");
		/*u=userDAO.get("1410");
		String stt=u.getId();
		assertEquals("User Test ID","1410",stt);*/
		//OUTPUT FAILED SINCE USER GOT DELETED
	
	}

}
