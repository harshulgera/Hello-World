package com.niit.shoppingcart.junit;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

public class TestCaseCategory 
{
	
	@Autowired
	static
	CategoryDAO categoryDAO;
	
	@Autowired
	static
	Category category;
	
	@Autowired
	static
	AnnotationConfigApplicationContext context;
	
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		categoryDAO= (CategoryDAO) context.getBean("categoryDAO");
		category=(Category) context.getBean("category");
		
	}


	@Test
	public void CategoryTestCase()
	{
		int size=categoryDAO.list().size();
		System.out.println(size);
		assertEquals("CategoryListTestCase",size,size);
		
		Category cat=categoryDAO.get("1803");
		String str=cat.getId();
		assertEquals("Category Test ID","1803",str);
		
		category.setId("PRD007");
		category.setName("One Plus 3");
		category.setDescription("Best Android Phone");
		categoryDAO.saveOrUpdate(category);
		//Testing Saved Category
		cat=categoryDAO.get("PRD007");
		String st=cat.getId();
		assertEquals("Category Test ID","PRD007",st);
		
		category.setId("1410");
		category.setName("One Plus 2");
		category.setDescription("multitasking phone");
		categoryDAO.saveOrUpdate(category);
		//Deleting Saved Category
		categoryDAO.delete("1410");
		/*u=categoryDAO.get("1410");
		String stt=u.getId();
		assertEquals("Category Test ID","1410",stt);*/
		//OUTPUT FAILED SINCE USER GOT DELETED
	
	}

}
