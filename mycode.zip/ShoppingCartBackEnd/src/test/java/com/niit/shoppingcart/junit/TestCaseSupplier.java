package com.niit.shoppingcart.junit;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class TestCaseSupplier 
{
	
	@Autowired
	static
	SupplierDAO supplierDAO;
	
	@Autowired
	static
	Supplier supplier;
	
	@Autowired
	static
	AnnotationConfigApplicationContext context;
	
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		supplierDAO= (SupplierDAO) context.getBean("supplierDAO");
		supplier=(Supplier) context.getBean("supplier");
		
	}


	@Test
	public void SupplierTestCase()
	{
		int size=supplierDAO.list().size();
		System.out.println(size);
		assertEquals("SupplierListTestCase",size,size);
		
		Supplier u=supplierDAO.get("1803");
		String str=u.getId();
		assertEquals("Supplier Test ID","1803",str);
		
		supplier.setId("14590");
		supplier.setName("Ritik Sinha");
		supplier.setAddress("Mumbai");
		supplierDAO.saveOrUpdate(supplier);
		//Testing Saved Supplier
		u=supplierDAO.get("1803");
		String st=u.getId();
		assertEquals("Supplier Test ID","1803",st);
		
		supplier.setId("1410");
		supplier.setAddress("pune");
		supplierDAO.saveOrUpdate(supplier);
		//Deleting Saved Supplier
		supplierDAO.delete("1410");
		/*u=supplierDAO.get("1410");
		String stt=u.getId();
		assertEquals("Supplier Test ID","1410",stt);*/
		//OUTPUT FAILED SINCE USER GOT DELETED
	
	}

}
