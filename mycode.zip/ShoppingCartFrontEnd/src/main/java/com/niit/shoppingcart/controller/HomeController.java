package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
/*import com.niit.shoppingcart.dao.UserDAO;*/
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;


@Controller

public class HomeController
{
	
	
	@Autowired
	User user;

	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private UserDAO userDAO;

	@Autowired
	private Category category;
	
	private static final Logger log = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session) 
	{
		log.debug("Starting of OnLoad");
		ModelAndView mv = new ModelAndView("home");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		log.debug("Ending of OnLoad");
		return mv;
	}
	
	@RequestMapping(value = "user/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute User user) 
	{
		log.debug("Starting of user/register");
		userDAO.saveOrUpdate(user);
		ModelAndView mv  = new ModelAndView("/home");
		mv.addObject("successMessage", "You are successfully register");
		log.debug("Ending of user/register");
		return mv;
	}

	@RequestMapping("/registerhere")
	public ModelAndView registerHere() 
	{
		log.debug("Starting of registerhere");
		ModelAndView mv = new ModelAndView("/register");
		mv.addObject("user", user);
		mv.addObject("isUserClickedRegisterHere", "true");
		log.debug("Ending of registerhere");
		return mv;
	}

	@RequestMapping("/loginhere")
	public ModelAndView loginHere() 
	{
		log.debug("Starting of loginhere");
		ModelAndView mv = new ModelAndView("/login");
		mv.addObject("user", new User());
		mv.addObject("isUserClickedLoginHere", "true");
		log.debug("Ending of loginhere");
		return mv;
	}

}
