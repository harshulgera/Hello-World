package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.DispatcherServlet;

import org.h2.command.ddl.SetComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.niit.shoppingcart.dao.CategoryDAO;
/*import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;*/
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;


@Controller
//@SessionAttributes("userID")
public class UserController /*extends AbstractController*/
{

	
	/* public UserController() {
		// TODO Auto-generated constructor stub
		 
		
	}*/

	private static final Logger log = LoggerFactory.getLogger(SupplierController.class);
	@Autowired
	UserDAO userDAO;

	
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private Category category;
	
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value = "name")String userID,@RequestParam(value = "password") String password, HttpSession session) 
	{
	
		
		log.debug("Starting of login");
		//System.out.println("MAPPING DONE");
		ModelAndView mv; 
		boolean isValidUser = userDAO.isValidUser(userID, password);
		if (isValidUser==true) 
		{
			mv=new ModelAndView("home");
			System.out.println("user valid");
			User user = userDAO.get(userID);
			session.setAttribute("loggedInUser", user.getName());
			if (user.getAdmin() == 1) 
			{
				mv.addObject("Admin", "true");

			} 
			else
			{
				mv.addObject("Admin", "false");
			}
		}
		else 
		{
			mv= new ModelAndView("login");
			System.out.println("returned FAlse");
					mv.addObject("errorMessage", "Invalid Credentials");
					mv.addObject("ClickedLoginHere", "true");
		}
		log.debug("Ending of login");
		return mv;
	}


	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/home");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
	
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }
}