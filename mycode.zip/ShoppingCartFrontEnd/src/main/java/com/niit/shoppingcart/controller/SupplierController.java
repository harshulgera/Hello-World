package com.niit.shoppingcart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

@Controller
public class SupplierController 
{
	private static final Logger log = LoggerFactory.getLogger(SupplierController.class);
	
	private SupplierDAO supplierDAO;
	
	@Autowired
	public void setSupplierDAO(SupplierDAO suplierDAO)
	{
		this.supplierDAO = suplierDAO;
	}
	
	@RequestMapping(value = "/suppliers", method = RequestMethod.GET)
	public String listSuppliers(Model mv) 
	{
		log.debug("Starting of Suppliers");
		mv.addAttribute("supplier", new Supplier());
		mv.addAttribute("supplierList", this.supplierDAO.list());
		log.debug("Ending of Suppliers");
		return "supplier";
	}
	
	
	@RequestMapping(value= "/supplier/add", method = RequestMethod.GET)
	public ModelAndView addSupplier(@ModelAttribute Supplier supplier)
	{
		log.debug("Starting of supplier/add");
		ModelAndView mv = new ModelAndView("supplier");
			System.out.println("Supplier Adding");
			supplierDAO.saveOrUpdate(supplier);
			mv.addObject("ClickedAddSupplier", "true");
			log.debug("Ending of supplier/add");
			return mv;
		
	}
	
	@RequestMapping("supplier/remove/{id}")
    public String removeSupplier(@PathVariable("id") String id,ModelMap mm) throws Exception
	{
		log.debug("Starting of supplier/remove");
		supplierDAO.delete(id);
		
      try 
       {
    	   
    	   mm.addAttribute("message","Successfully Added");
       } 
       catch (Exception e) 
       {
    	   mm.addAttribute("message",e.getMessage());
    	   e.printStackTrace();
       }
  	log.debug("Ending of supplier/remove");
      return "redirect:/suppliers";
    }
 
    @RequestMapping("supplier/edit/{id}")
    public String editSupplier(@PathVariable("id") String id,Model mv)
    {
    	log.debug("Starting of supplier/edit");
    	System.out.println("Entering edit");
        mv.addAttribute("supplier", this.supplierDAO.get(id));
        mv.addAttribute("listSuppliers", this.supplierDAO.list());
        log.debug("Ending of supplier/edit");
        return "redirect:/suppliers";
    }
}
