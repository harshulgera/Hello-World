package com.niit.shoppingcart.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.SupplierDAOImpl;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;

@Controller
public class AdminController 
{
	
	@Autowired
	private Product product;

	@Autowired
	private Supplier supplier;

	@Autowired
	private Category category;
	
	@Autowired
	private SupplierDAO supplierDAO;
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	
	@Autowired
	private ProductDAO productDAO;

	private static final Logger log = LoggerFactory.getLogger(AdminController.class);
	
	@RequestMapping("/manageCategories")
	public ModelAndView categories() 
	{
		log.debug("Starting of Manage Categories");
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("category", category);
		mv.addObject("ClickedCategories", "true");
		mv.addObject("categoryList", categoryDAO.list());
		log.debug("Ending of Manage Categories");
		return mv;
	}

	@RequestMapping("/manageProducts")
	public ModelAndView suppliers() 
	{
		log.debug("Starting of Manage Products");
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("product", product);
		mv.addObject("ClickedProducts", "true");
		mv.addObject("productList", productDAO.list());
		log.debug("Ending of Manage Products");
		return mv;
	}

	@RequestMapping("/manageSuppliers")
	public ModelAndView products() 
	{
		log.debug("Starting of Manage ");
		log.debug("Ending of Manage Suppliers");
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("supplier", supplier);
		mv.addObject("ClickedSuppliers", "true");
		mv.addObject("supplierList", supplierDAO.list());
		log.debug("Starting of Manage ");
		log.debug("Ending of Manage Suppliers");
		return mv;
	}

}


